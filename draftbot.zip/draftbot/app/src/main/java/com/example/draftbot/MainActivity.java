package com.example.draftbot;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.aichatbot.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    TextView welcomeTextView;
    EditText messageEditText;
    ImageButton sendButton;
    ImageButton clearButton;
    ImageButton speechButton, copyButton;
    List<Message> messageList;
    MessageAdapter messageAdapter;
    public static final MediaType JSON
            = MediaType.get("application/json; charset=utf-8");
    OkHttpClient client = new OkHttpClient();
    TextToSpeech tts;
    ClipboardManager clipboard;
    private static final int REQUEST_CODE_SPEECH_INPUT = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        messageList = new ArrayList<>();

        recyclerView = findViewById(R.id.recycler_view);
        welcomeTextView = findViewById(R.id.welcome_text);
        messageEditText = findViewById(R.id.message_edit_text);
        sendButton = findViewById(R.id.send_btn);
        clearButton = findViewById(R.id.clearButton);
        speechButton = findViewById(R.id.speech_button);
        copyButton = findViewById(R.id.copy_button);

        // Setup recycler view
        messageAdapter = new MessageAdapter(messageList);
        recyclerView.setAdapter(messageAdapter);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setStackFromEnd(true);
        recyclerView.setLayoutManager(llm);

        clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);

        sendButton.setOnClickListener((v) -> {
            String question = messageEditText.getText().toString().trim();
            addToChat(question, Message.SENT_BY_ME);
            messageEditText.setText("");
            callAPI(question);
            welcomeTextView.setVisibility(View.GONE);
        });

        clearButton.setOnClickListener((v) -> {
            clearChat();
        });

        messageEditText.requestFocus();
        showKeyboard();

        initializeTextToSpeech();

        speechButton.setOnClickListener((v) -> {
            startSpeechToText();
        });

        copyButton.setOnClickListener((v) -> {
            String response = getLastResponse();
            if (!response.isEmpty()) {
                copyToClipboard(response);
            }
        });

        checkTextToSpeechData();

        RelativeLayout bottomLayout = findViewById(R.id.bottom_layout);
        final ViewTreeObserver.OnGlobalLayoutListener globalLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Rect r = new Rect();
                bottomLayout.getWindowVisibleDisplayFrame(r);
                int screenHeight = bottomLayout.getRootView().getHeight();

                int keypadHeight = screenHeight - r.bottom;

                if (keypadHeight > screenHeight * 0.15) { // Adjust the threshold as needed
                    clearButton.setVisibility(View.GONE);
                } else {
                    clearButton.setVisibility(View.VISIBLE);
                }
            }
        };

        bottomLayout.getViewTreeObserver().addOnGlobalLayoutListener(globalLayoutListener);
    }

    private void startSpeechToText() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak something...");

        try {
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
        } catch (Exception e) {
            Toast.makeText(this, "Speech recognition not supported on your device", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_SPEECH_INPUT && resultCode == RESULT_OK && data != null) {
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (result != null && !result.isEmpty()) {
                String spokenText = result.get(0);
                messageEditText.setText(spokenText);
            }
        }
    }

    private void initializeTextToSpeech() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.ERROR) {
                tts.setLanguage(Locale.getDefault());
            }
        });
    }

    private void checkTextToSpeechData() {
        PackageManager pm = getPackageManager();
        int result = pm.checkPermission(Manifest.permission.RECORD_AUDIO, getPackageName());
        if (result != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, 0);
        }
    }

    private void speakResponse(String response) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            tts.speak(response, TextToSpeech.QUEUE_FLUSH, null, null);
        } else {
            HashMap<String, String> params = new HashMap<>();
            tts.speak(response, TextToSpeech.QUEUE_FLUSH, params);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
    }

    void addToChat(String message, String sentBy) {
        runOnUiThread(() -> {
            messageList.add(new Message(message, sentBy));
            messageAdapter.notifyDataSetChanged();
            recyclerView.smoothScrollToPosition(messageAdapter.getItemCount());
        });
    }

    void addResponse(String response, String sentBy) {
        runOnUiThread(() -> {
            messageList.add(new Message(response, sentBy));
            messageAdapter.notifyDataSetChanged();
            recyclerView.smoothScrollToPosition(messageAdapter.getItemCount());
        });
    }

    void clearChat() {
        messageList.clear();
        messageAdapter.notifyDataSetChanged();
    }


    void callAPI(String question) {
        // Show typing indicator
        addResponse("Typing...", Message.SENT_BY_BOT);

        // OkHttp
        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("model", "text-davinci-003");
            jsonBody.put("prompt", question);
            jsonBody.put("max_tokens", 4000);
            jsonBody.put("temperature", 0);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody body = RequestBody.create(jsonBody.toString(), JSON);
        Request request = new Request.Builder()
                .url("https://api.openai.com/v1/completions")
                .header("Authorization", "Bearer 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")
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                runOnUiThread(() -> {
                    // Hide typing indicator and show error message
                    addResponse("Failed to load due to " + e.getMessage(), Message.SENT_BY_BOT);
                });
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObject = new JSONObject(response.body().string());
                        JSONArray jsonArray = jsonObject.getJSONArray("choices");
                        String result = jsonArray.getJSONObject(0).getString("text");

                        runOnUiThread(() -> {
                            // Remove typing indicator message
                            if (!messageList.isEmpty() && messageList.get(messageList.size() - 1).getMessage().equals("Typing...")) {
                                messageList.remove(messageList.size() - 1);
                                messageAdapter.notifyDataSetChanged();
                            }

                            // Show the response
                            addResponse(result.trim(), Message.SENT_BY_BOT);
                            speakResponse(result.trim());
                        });
                    } catch (JSONException e) {
                        e.printStackTrace();

                        runOnUiThread(() -> {
                            // Hide typing indicator and show error message
                            addResponse("Failed to parse response", Message.SENT_BY_BOT);
                        });
                    }
                } else {
                    runOnUiThread(() -> {
                        try {
                            // Hide typing indicator and show error message
                            addResponse("Failed to load due to " + response.body().string(), Message.SENT_BY_BOT);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
                }
            }
        });
    }

    private void showKeyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (inputMethodManager != null) {
            inputMethodManager.showSoftInput(messageEditText, InputMethodManager.SHOW_IMPLICIT);
        }
    }

    private String getLastResponse() {
        int lastIndex = messageList.size() - 1;
        if (lastIndex >= 0) {
            Message lastMessage = messageList.get(lastIndex);
            if (lastMessage.getSentBy().equals(Message.SENT_BY_BOT)) {
                return lastMessage.getMessage();
            }
        }
        return "";
    }

    private void copyToClipboard(String text) {
        ClipData clipData = ClipData.newPlainText("Response", text);
        clipboard.setPrimaryClip(clipData);
        Toast.makeText(this, "Response copied", Toast.LENGTH_SHORT).show();
    }
}
